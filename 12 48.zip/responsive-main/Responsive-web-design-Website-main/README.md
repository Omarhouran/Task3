# Responsive-web-design-Website
**Mandatory Task!**

Dear Interns,

The task is to completely modify/customize this bootstrap project. Use your creativity to write your first very own website with Responsive web design(RWD).

**Your website should must contain:**
* 5 Sections. (i-e Services,Portfolio, About etc)
* Information about your past coding activity/projects.
* Information about your academics (i-e Academic story,history,experience in uni etc)
* Your favourites (i-e The preference on your favourites Activities, Food, Sports etc)

You can manage to adjust the above points in the website sections.

Should you have questions do not hesitate to contact us. We are open 24/7.

(email: TechLead@LimeLightR.org)
